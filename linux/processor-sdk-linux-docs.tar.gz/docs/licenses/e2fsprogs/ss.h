/*
 * Copyright 1987, 1988 by MIT Student Information Processing Board
 *
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose is hereby granted, provided that
 * the names of M.I.T. and the M.I.T. S.I.P.B. not be used in
 * advertising or publicity pertaining to distribution of the software
 * without specific, written prior permission.  M.I.T. and the
 * M.I.T. S.I.P.B. make no representations about the suitability of
 * this software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 *
 * This quote is just too good to not pass on:
 *
 * 	"BTW, I would have rejected the name Story Server because its
 * 	initials are SS, the name of the secret police in Nazi
 * 	Germany, probably the most despised pair of letters in western
 * 	culture."  --- http://scriptingnewsarchive.userland.com/1999/12/13
 *
 * Let no one say political correctness isn't dead....
